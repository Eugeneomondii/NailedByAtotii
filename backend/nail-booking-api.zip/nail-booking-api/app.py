import click
from flask import Flask, jsonify
from flask_cors import CORS

from config import Config
from extensions import db, jwt, limiter, migrate
from models import Admin, Service


def create_app(config_object=Config):
    app = Flask(__name__)
    app.config.from_object(config_object)

    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    limiter.init_app(app)
    CORS(app, origins=app.config["CORS_ORIGINS"])

    from routes_admin import admin_bp
    from routes_public import public_bp
    app.register_blueprint(public_bp)
    app.register_blueprint(admin_bp)

    @app.get("/api/health")
    def health():
        return jsonify({"status": "ok"})

    @app.errorhandler(404)
    def not_found(_):
        return jsonify({"error": "Not found"}), 404

    @app.errorhandler(429)
    def too_many(_):
        return jsonify({"error": "Too many requests. Please try again later."}), 429

    register_cli(app)
    return app


def register_cli(app):
    @app.cli.command("create-admin")
    @click.argument("username")
    @click.password_option()
    def create_admin(username, password):
        """Create the owner's admin login."""
        admin = Admin(username=username)
        admin.set_password(password)
        db.session.add(admin)
        db.session.commit()
        click.echo(f"Admin '{username}' created.")

    @app.cli.command("seed-services")
    def seed_services():
        """Insert sample services. Replace names and prices with hers."""
        samples = [
            ("Gel Manicure", 1500, 60),
            ("Acrylic Full Set", 2500, 120),
            ("Pedicure", 1800, 75),
            ("Nail Art (add-on)", 500, 30),
            ("Removal", 500, 30),
        ]
        for name, price, mins in samples:
            if not Service.query.filter_by(name=name).first():
                db.session.add(Service(name=name, price=price, duration_min=mins))
        db.session.commit()
        click.echo("Sample services added.")


app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
